package dev.practice.gift.domain.gift;

public interface GiftStore {
    Gift store(Gift gift);
}
